
<div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Tambah User</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            
        <div class="body">
          <form method="POST" onSubmit="validasi()">
            <div class="box-body">
                <div class="form-group">
                  <label for="">Nama</label>
                  <input type="text" class="form-control" name="nama" id="nama"/>
                </div>

                <div class="form-group">
                  <label for="">Email</label>
                  <input type="email" class="form-control" name="email" id="email"/>
                </div>

                <div class="form-group">
                  <label for="">Password</label>
                  <input type="password" class="form-control" name="password" id="password"/>
                </div>

                <div class="form-group">
                  <label for="">Nama Toko</label>
                  <input type="text" class="form-control" name="nama_toko" id="nama_toko"/>
                </div>

                <div class="form-group">
                  <label>Level</label>
                    <select name="level"class="form-control show-tick">
                        <option value="">-- Pilih Level --</option>
                        <option value="admin">Admin</option>
                        <option value="penjual">Penjual</option>
                        
                                        
                    </select>
                </div>

                
                  <input type="submit" name="simpan" value="Simpan" class="btn btn-primary">

              </div>
            </form>
          </div>
        </div>
    </div>
</div>



<?php 

        if (isset($_POST['simpan'])) {
            
            $nama = $_POST['nama'];
            $email = $_POST['email'];
            $password = $_POST['password'];
            $nama_toko = $_POST['nama_toko'];
            $level = $_POST['level'];

            if(empty($nama) || empty($email) || empty($password) || empty($nama_toko) || empty($level)){
              ?>
             <script type="text/javascript">
              alert("Anda harus mengisi data dengan lengkap !");
             </script>

             <?php
          }else{

            $sql = $koneksi->query("insert into tb_user (nama, email, password, nama_toko, level) values('$nama', '$email', '$password', 'nama_toko', '$level')");
                ?> 

                    <script type="text/javascript">
                        alert("Data Berhasil Disimpan");
                        window.location.href="?page=user";
                    </script>

                <?php  

          }
        

        }
     ?>