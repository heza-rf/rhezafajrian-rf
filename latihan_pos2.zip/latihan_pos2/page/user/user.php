<section class="content-header">
<div class="box">
  
  <div class="box-header">
        <h3 class="box-title">Data Produk</h3>
  </div>

<div class="box-body table-responsive no-padding">

  <div class="col-md-12">
    <br>
    <table id_user="example1" class="table table-bordered table-striped">
      <thead>
      <tr>
        <th>ID User</th>
        <th>Nama</th>
        <th>Email</th>
        <th>Nama Toko</th>
        <th>No Hp</th>
        <th>Alamat</th>
        <th>Level</th>

        <th>Aksi</th>
      </tr>
      </thead>

    <tbody>
      
      <?php 

                                  

          $sql = $koneksi->query("select * from tb_user");

          while ($data = $data = $sql->fetch_assoc()){

          ?>
            <tr>
                              
              <td><?php echo $data['id_user']; ?></td>
              <td><?php echo $data['nama']; ?></td>
              <td><?php echo $data['email']; ?></td>
              <td><?php echo $data['nama_toko']; ?></td>
              <td><?php echo $data['no_hp']; ?></td>
              <td><?php echo $data['alamat']; ?></td>
              <td><?php echo $data['level']; ?></td>
                                        
                                                             
              <td>
                                          
                <a href="?page=user&aksi=ubah&id_user=<?php echo $data['id_user'] ?>" class="btn btn-success" >EDIT</a>
                <a onclick="return confirm('Apakah Anda Akan Menghapus Data Ini ?')" href="?page=user&aksi=hapus&id_user=<?php echo $data['id_user'] ?>" class="btn btn-danger" >hapus</a>
              </td>
            </tr>
                                    
          <?php } ?>  

  </tbody>
  </table>
  <a href="?page=user&aksi=tambah" class="btn btn-primary" >Tambah</a>
  <br><br>
</div>
</div>
</div>
</section>


