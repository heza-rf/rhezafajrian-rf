<?php 

    $id_user = $_GET['id_user'];

    $sql = $koneksi->query("select * from tb_user where id_user ='$id_user'");
    $tampil = $sql->fetch_assoc();

    $level = $tampil['level'];


 ?>

<div class="row">
    <div class="col-md-12">
     <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">Edit User</h3>
            </div>

                <div class="body">
                <form method="POST">


                <div class="box-body">
                <label for="">Nama</label>
                    <div class="form-group">
                       <input type="text" name="nama" value="<?php echo $tampil['nama']; ?>" class="form-control" />
                    </div>
                

                    <label for="">Email</label>
                  
                      <div class="form-group">
                        <input type="email" name="email" value="<?php echo $tampil['email']; ?>" class="form-control" />
                      </div>
                 

                    <label for="">Password</label>
                      <div class="form-group">
                        <input type="password" name="password" value="<?php echo $tampil['password']; ?>" class="form-control" />
                      </div>
                

                    <label for="">Nama Toko</label>
                      <div class="form-group">
                        <input type="text" name="nama_toko" value="<?php echo $tampil['nama_toko']; ?>" class="form-control" />
                      </div>
               

                    <label for="">Level</label>
                      
                      <div class="form-group">
                        <select name="level"class="form-control show-tick">
                            <option value="admin"<?php if ($level=='admin'){ echo "selected"; } ?>>Admin</option>
                            <option value="penjual"<?php if ($level=='penjual'){ echo "selected"; } ?>>Penjual</option>
                        </select>
                      </div>
               

                    <input type="submit" name="simpan" value="Simpan" class="btn btn-primary">

                </div>
            </form>
        </div>
    </div>



    <?php 

        if (isset($_POST['simpan'])) {
            
            $nama = $_POST['nama'];
            $email = $_POST['email'];
            $password = $_POST['password'];
            $nama_toko = $_POST['nama_toko'];
            $level = $_POST['level'];

            $sql2 = $koneksi->query("update tb_user set nama='$nama', password='$password', nama_toko='$nama_toko', level='$level' where id_user='$id_user'");

            if ($sql2) {
                ?> 

                    <script type="text/javascript">
                        alert("Data Berhasil Diubah");
                        window.location.href="?page=user";
                    </script>

                <?php  
            }
        }


     ?>