<?php 

    $id_user = $_GET['id_user'];

    $sql = $koneksi->query("DELETE  FROM tb_user WHERE id_user ='$id_user'");

    if ($sql) {
                ?> 

                    <script type="text/javascript">
                        alert("Data Berhasil Dihapus");
                        window.location.href="?page=user";
                    </script>

                <?php  
            }
        


 ?>