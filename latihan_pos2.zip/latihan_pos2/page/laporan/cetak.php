<?php 
		error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));

		$koneksi = new mysqli("localhost", "root", "", "dbpos");

		$user = $_GET['id_us'];

    	


 ?>

 <style>
 	
 		@media print {
 			input.noPrint{
 				display: none;
 			}
 		}

 </style>



  <table>
 	<?php 
 	$sql = $koneksi->query("select * from tb_transaksi where id_user='$user'");
    
    $data = $sql->fetch_assoc();

 	 ?>
 	<tr>
 		<td><?php echo $user; ?></td>
 	</tr>



 </table>

 <table border="1" width="100%" style="border-collapse: collapse;">
 	<caption>LAPORAN PENJUALAN</caption>
 	<thead>
 		<tr>
 			<th>No</th>
 			<th>Tanggal</th>
 			<th>Kode Barcode</th>
 			<th>Nama Barang</th>
 			<th>Harga Jual</th>
 			<th>Qty</th>
 			<th>Total</th>
 			<th>Profit</th>
 			<th>Profit</th>
 		</tr>
 	</thead>
 	<tbody>
 		<?php 

 				$tgl_awal = $_POST['tgl_awal'];
 				$tgl_akhir = $_POST['tgl_akhir'];
 				
 			

 				$no = 1;
 				$sql2 = $koneksi->query("select * from tb_transaksi, tb_barang where 
 					tb_transaksi.kode_barcode=tb_barang.kode_barcode
 					and tb_transaksi.id_user=tb_barang.id_user
 					and tb_transaksi.id_user='$user'
 					and tgl_transaksi 
 					between '$tgl_awal' and '$tgl_akhir' ");
 				

 				while ($data2 = $sql2->fetch_assoc()) {

 					$profit = $data2['profit'] * $data2['jumlah'];
 					
 		 ?>

 		 <tr>
 		 	<td><?php echo $no++; ?></td>
 		 	<td><?php echo date('d F Y', strtotime( $data2['tgl_transaksi'] )) ?></td>
 		 	<td><?php echo $data2['kode_barcode'] ?></td>
 		 	<td><?php echo $data2['nama_barang'] ?></td>
 		 	<td><?php echo number_format($data2['harga_jual']) ?></td>
 		 	<td><?php echo $data2['jumlah'] ?></td>
 		 	<td><?php echo number_format($data2['total']) ?></td>
 		 	<td><?php echo number_format($profit) ?></td>
 		 	<td><?php echo $data2['id_user'] ?></td>
 		 </tr>


 		<?php 

 		$total_pj = $total_pj + $data2['total'];

 		$total_profit = $total_profit + $profit;




 		} 


 		?>
 	</tbody>
 	<tr>
 		<th colspan="6">Total Penjualan dan Profit</th>
 		<td><?php echo number_format($total_pj) ?></td>
 		<td><?php echo number_format($total_profit) ?></td>
 	</tr>

 </table>

 <br>
 <input type="button" value="Cetak" class="noPrint" onclick="window.print()">