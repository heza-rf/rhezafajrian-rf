<?php 

$jumlah 	= $_GET['jumlah'];
$id 		= $_GET['id'];
$kode 		= $_GET['kodepj'];
$harga_jual = $_GET['harga_jual'];
$kode_b 	= $_GET['kode_barcode'];

$sql  = $koneksi->query("delete from tb_transaksi where kode_barcode='$kode_b'");
$sql2 = $koneksi->query("update tb_barang set stok=(stok + $jumlah) where kode_barcode='$kode_b'");

if ($sql || $sql1 || $sql2) {
	?>
	<script>
		window.location.href="?page=transaksi&kodepj=<?php echo $kode ?>";
	</script>
	<?php
}
 ?>