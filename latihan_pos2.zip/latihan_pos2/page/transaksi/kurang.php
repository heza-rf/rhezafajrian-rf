<?php 

$id = $_GET['id'];
$kode = $_GET['kodepj'];
$harga_jual = $_GET['harga_jual'];
$kode_b = $_GET['kode_barcode'];

$sql  = $koneksi->query("update tb_transaksi set jumlah=(jumlah-1) where kode_barcode='$kode_b'");
$sql1 = $koneksi->query("update tb_transaksi set total=(total-$harga_jual) where kode_barcode='$kode_b'");
$sql2 = $koneksi->query("update tb_barang set stok=(stok+1) where kode_barcode='$kode_b'");

if ($sql || $sql1 || $sql2) {
	?>
	<script>
		window.location.href="?page=transaksi&kodepj=<?php echo $kode ?>";
	</script>
	<?php
}
 ?>