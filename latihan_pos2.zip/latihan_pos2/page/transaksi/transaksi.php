<?php 

    $kode = $_GET['kodepj'];

    $kasir = $data['nama_toko'];
    
    $sql = $koneksi->query("select * from tb_barang where id_user='$user'");
    
    $data = $sql->fetch_assoc();


 ?>


<div class="row clearfix">                    

    <div class="body">
      <form method="POST">

          <div class="col-md-2">
            <input type="text" name="kode" value="<?php echo $kode; ?>" class="form-control" readonly="" />
          </div>

          <div class="col-md-2">
            <input type="text" name="id_user" value="<?php echo $data['id_user']; ?>" class="form-control" readonly="" />
          </div>

          <div class="col-md-2">
            <input type="text" name="kode_barcode" id="kode_barcode" class="form-control" autofocus=""  required="" />
          </div>

          <div class="col-md-2">
            <input type="submit" name="simpan" value="Tambahkan" class="btn btn-primary">
          </div>


      </form>
    </div>
    <br><br>


<form method="POST">
<div class="col-md-6">
  <div class="box box-primary collapsed-box">
      <div class="box-header with-border">
        <h3 class="box-title">Pilih Barang</h3>

        <div class="box-tools pull-right">
          <button type="button" class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip"><i class="fa fa-minus"></i>
          </button>
        </div>
      </div>
      <!-- /.box-header -->
      <div class="box-body">
        <ul class="products-list product-list-in-box">
          <?php 

                $no   = 1;

                $sql  = $koneksi->query("select * from tb_barang where id_user='$user'");

                 while ($data = $data = $sql->fetch_assoc()){

            ?>
          <li class="item">
            <div class="product-img">
              <img src="dist/img/<?php echo $data['foto']; ?>" alt="Product Image">
            </div>
            <div class="product-info">
              <a href="javascript:void(0)" class="product-title"><?php echo $data['nama_barang'] ?>
                <span class="label label-info pull-right"><?php echo number_format($data['harga_jual']) ?></span></a>
              <span class="product-description">
                Barcode :<?php echo $data['kode_barcode'] ?>
                  </span>
            </div>
          </li>

            <?php } ?>

          
        </ul>
      </div>
    </form>
      <!-- /.box-body -->
      <div class="box-footer text-center">
        <a href="javascript:void(0)" class="uppercase">View All Products</a>
      </div>
            <!-- /.box-footer -->
    </div>
  </div>


<?php 


        if (isset($_POST['simpan'])) {

            $date = date("Y-m-d");

            $kd_pj = $_POST['kode'];

            $id_user = $_POST['id_user'];

            $barcode = $_POST['kode_barcode'];

            $nama_barang = $_POST['nama_barang'];

            $barang = $koneksi->query("select * from tb_barang where id_user='$id_user' AND kode_barcode='$barcode'");

            $data_barang=$barang->fetch_assoc();

            $harga_jual = $data_barang['harga_jual'];

            $jumlah = 1;

            $total = $jumlah * $harga_jual;

            $barang2 = $koneksi->query("select * from tb_barang where id_user='$id_user' AND kode_barcode='$barcode'");

            while ($data_barang2 = $barang2->fetch_assoc()) {
                $sisa = $data_barang2['stok'];

                if ($sisa == 0) {
                    ?>
                        <script type="text/javascript">
                            
                            alert("stok barang habis");
                            window.location.href="?page=transaksi&kodepj=<?php echo $kode; ?>"
                        </script>

                    <?php
                    }

                else {

                    $koneksi->query("insert into tb_transaksi (id_user, kode_transaksi, kode_barcode, jumlah, total, tgl_transaksi)values('$id_user','$kd_pj', '$barcode', '$jumlah', '$total', '$date')");
                }   
            }

        }

 ?>


<!-- /.box invoice--------------------------------------------------------------------- -->

<form method="POST">
 <div class="col-md-6">
  <div class="box box-info box-solid">
      <div class="box-header with-border">
        <h3 class="box-title">Daftar Belanjaan</h3>

        <div class="box-tools pull-right">
          <button type="button" class="btn btn-info btn-sm" data-widget="collapse"><i class="fa fa-minus"></i>
          </button>
        </div>
      </div>
      <!-- /.box-header -->
      <div class="box-body">
        <table class="table no-margin">
          
          <thead>
            <tr>
              <th>Kode Transaksi</th>
              <th>Kode Barcode</th>
              <th>Nama Barang</th>
              <th>Qty</th>
              <th></th>
              <th>Total</th>
              
            </tr>
          </thead>
          <tbody>
          <?php 

                $no   = 1;

                $sql = $koneksi->query("select * from tb_transaksi, tb_barang where tb_transaksi.kode_barcode=tb_barang.kode_barcode and tb_barang.id_user=tb_transaksi.id_user AND kode_transaksi='$kode'");

                 while ($data = $data = $sql->fetch_assoc()){
            ?>
            <tr>
              <td><?php echo $data['kode_transaksi']; ?></td>
              <td><?php echo $data['kode_barcode']; ?></td>
              <td><?php echo $data['nama_barang']; ?></td>
              <td><?php echo $data['jumlah']; ?></td>
              <td>
                <div class="btn-group">
                  <button type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown">
                    <span class="caret"></span>
                  </button>
                    <ul class="dropdown-menu">
                      <li><a href="?page=transaksi&aksi=tambah&id=<?php echo $data['id'] ?>&kodepj=<?php echo $data[
                      'kode_transaksi'] ?>&harga_jual=<?php echo $data['harga_jual'] ?>&kode_barcode=<?php echo $data['kode_barcode'] ?>">Tambah</a></li>
                      <li><a href="?page=transaksi&aksi=kurang&id=<?php echo $data['id'] ?>&kodepj=<?php echo $data[
                      'kode_transaksi'] ?>&harga_jual=<?php echo $data['harga_jual'] ?>&kode_barcode=<?php echo $data['kode_barcode'] ?>">Kurang</a></li>


                      <li><a onclick="return confirm('Hapus Data Ini ?')" href="?page=transaksi&aksi=hapus&id=<?php echo $data['id'] ?>&kodepj=<?php echo $data[
                      'kode_transaksi'] ?>&harga_jual=<?php echo $data['harga_jual'] ?>&kode_barcode=<?php echo $data['kode_barcode'] ?>&jumlah=<?php echo $data['jumlah'] ?>">Hapus</a></li>
                    </ul>
                </div>
              </td> 
              <td><?php echo $data['total']; ?></td>   
                
            </tr>
              <?php 

                $total_bayar = $total_bayar + $data['total'];

                }


             ?> 

            </tbody>
             <a type="submit" value="Cetak Struk" onclick="window.open('page/transaksi/cetak.php?kode_pjl=<?php echo $kode; ?>&kasir=<?php echo $kasir; ?>','mywindow','width=300px, height=500px, left=300px;')"  class="btn btn-app pull-right"> 
            <i class="glyphicon glyphicon-list-alt" ></i> Cetak</a> 
            <input type="submit" name="simpan_pj" value="Simpan" class="btn btn-app pull-right ">

         </table>
          <hr>

            

          <table>
            
              <tr>
                <th width="70%" colspan="5" style="text-align: right;">Total</th>
                <td><input type="text" name="total_bayar" id="total_bayar" onkeyup="hitung();" value="<?php echo $total_bayar; ?>" readonly=""></td>
              </tr>

              <tr>
                  <th colspan="5" style="text-align: right;">Diskon</th>
                  <td> <input type="number" name="diskon" id="diskon" onkeyup="hitung();"> </td>
              </tr>

              <tr>
                  <th colspan="5" style="text-align: right;">Potongan Diskon</th>
                  <td> <input type="number" name="potongan" id="potongan" onkeyup="hitung();"> </td>
              </tr>

              <tr>
                  <th colspan="5" style="text-align: right;">Sub Total</th>
                  <td> <input type="number" name="total_b" id="total_b"> </td>
              </tr>

              <tr>
                  <th colspan="5" style="text-align: right;">Bayar</th>
                  <td> <input type="number" name="bayar" id="bayar" onkeyup="hitung();"> </td>
              </tr>

              <tr>
                  <th colspan="5" style="text-align: right;">Kembali</th>
                  <td> <input type="number" name="kembali" id="kembali"> 
                  
                  </td>
              </tr>
            
            
          </table>
      <!-- /.box-body -->
    </div>
  </form>
  </div>

<?php 

    if(isset($_POST['simpan_pj'])) {

      
      $total_bayar = $_POST['total_bayar'];
      $diskon = $_POST['diskon'];
      $potongan = $_POST['potongan'];
      $total_b = $_POST['total_b'];

      $bayar = $_POST['bayar'];
      $kembali = $_POST['kembali'];

      $koneksi->query("insert into tb_transaksi_detail(id_user, kode_transaksi, bayar, kembali, diskon, potongan, total_b)values('$user', '$kode', '$bayar', '$kembali', '$diskon', '$potongan', '$total_b')");



    }


 ?>

  <script type="text/javascript">
    
    function hitung(){

        var total_bayar = document.getElementById('total_bayar').value;

        var diskon = document.getElementById('diskon').value;

        var diskon_pot = parseInt(total_bayar) * parseInt(diskon) / parseInt(100);

        if (!isNaN(diskon_pot)) {

            var potongan = document.getElementById('potongan').value = diskon_pot;
        }

        var sub_total = parseInt(total_bayar) - parseInt(potongan);

        if (!isNaN(sub_total)) {

            var s_total = document.getElementById('total_b').value = sub_total;
        }

        var bayar = document.getElementById('bayar').value;

        var bayar_b = parseInt(bayar) - parseInt(s_total);

        if (!isNaN(bayar_b)) {

            document.getElementById('kembali').value = bayar_b;
        }
    }

</script>