<?php 

		error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
	
		$koneksi = new mysqli("localhost", "root", "", "dbpos");

		$id 		= $_GET['id_user'];
		$kode 		= $_GET['kodepj'];
		$kode_b 	= $_GET['kode_barcode'];

		if(isset($_SESSION['keranjang'][$kode_b]))
		{
			$_SESSION['keranjang'][$kode_b]+1;
		}

		else
		{
			$_SESSION['keranjang'][$kode_b] = 1;
		}

		echo "<script>alert('produk telah masuk kekeranjang belanja');</script>";
		echo "<script>location=?page=transaksi&kodepj=<?php echo $kode; ?></script>";

		else
		{
			$koneksi->query("insert into tb_transaksi (id_user, kode_transaksi, kode_barcode, jumlah, total, tgl_transaksi)values('$id_user','$kd_pj', '$barcode', '$jumlah', '$total', '$date')");
		}






 ?>