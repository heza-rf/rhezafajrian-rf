<!-- Main content -->
    <section class="invoice">
      <!-- title row -->
      <div class="row">
        <div class="col-xs-12">
          <h2 class="page-header">
            <i class="fa fa-globe"></i> AdminLTE, Inc.
            <small class="pull-right">Date: 2/10/2014</small>
          </h2>
        </div>
        <!-- /.col -->
      </div>
      <!-- info row -->

      <?php 

            if ($_SESSION['admin']) {
              $user = $_SESSION['admin'];
            }elseif ($_SESSION['penjual']){
              $user = $_SESSION['penjual'];
            }

         $kode_transaksi = $_GET['kode_transaksi'];

            $sql2 = $koneksi->query("select tb_user.id_user, tb_user.nama, tb_barang.id from tb_user, tb_barang where tb_user.id_user=tb_barang.id");
            $sql = $koneksi->query("select * from tb_transaksi where kode_transaksi ='$kode_transaksi'");
            $tampil = $sql->fetch_assoc();

      ?>

      <div class="row invoice-info">
        <div class="col-sm-4 invoice-col">
          
          <address>
            <strong><?php echo $data['nama']; ?>, <?php echo $data['nama_toko']; ?>.</strong><br>
            <?php echo $data['alamat']; ?><br>
            <?php echo $data['no_hp']; ?><br>
            <?php echo $data['email']; ?><br>
            
          </address>
        </div>
        <!-- /.col -->
        
        <!-- /.col -->
        <div class="col-sm-4 invoice-col">
          <b><?php echo $kode_transaksi ?></b><br>

          <br>
          <b><?php echo $data['tgl_transaksi']; ?><br>
          
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- Table row -->
      <div class="row">
        <div class="col-xs-12 table-responsive">
          <table class="table table-striped">
          
          <thead>
            <tr>
              <th>Qty</th>
              <th>Nama Barang</th>
              <th>Kode Barcode</th>
              <th>Total</th>
              
              
            </tr>
          </thead>
          <?php 

                $no   = 1;

               $sql = $koneksi->query("select * from tb_transaksi, tb_barang where tb_transaksi.kode_barcode=tb_barang.kode_barcode and tb_barang.id_user=tb_transaksi.id_user AND kode_transaksi='$kode_transaksi'");

                 while ($data = $data = $sql->fetch_assoc()){
            ?>
          <tbody>
          
            <tr>
              <td><?php echo $data['jumlah']; ?></td>
              <td><?php echo $data['nama_barang']; ?></td>
              <td><?php echo $data['kode_barcode']; ?></td>
              <td><?php echo $data['total']; ?></td>     
            </tr>
              <?php 

                $total_bayar = $total_bayar + $data['total'];

                }


             ?>  
            </tbody>
         </table>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <div class="row">
        <!-- accepted payments column -->
        <div class="col-xs-6">
          <p class="lead">Payment Methods:</p>
          <img src="dist/img/credit/visa.png" alt="Visa">
          <img src="dist/img/credit/mastercard.png" alt="Mastercard">
          <img src="dist/img/credit/american-express.png" alt="American Express">
          <img src="dist/img/credit/paypal2.png" alt="Paypal">

          <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
            Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles, weebly ning heekya handango imeem plugg
            dopplr jibjab, movity jajah plickers sifteo edmodo ifttt zimbra.
          </p>
        </div>
        <!-- /.col -->


        
        <div class="col-xs-6">
          <?php 
                $kode = $_GET['kodepj'];

                $sql5 = $koneksi->query("select * from tb_transaksi_detail where kode_transaksi='$kode'");
    
                $data = $sql5->fetch_assoc();



           ?>
          <p class="lead">Amount Due 2/22/2014</p>

          <div class="table-responsive">
            <table class="table">

              <tr>
                <th style="width:50%">Subtotal:</th>
                <td id="total_bayar" onkeyup="hitung();">Rp.<?php echo $total_bayar; ?></td>
              </tr>
              

              <tr>
                <th>Diskon:</th>
                <td>Rp.<?php echo $data['diskon']; ?></td>
              </tr>

              <tr>
                  <th>Potongan Diskon</th>
                  <td> <?php echo $data['potongan']; ?> </td>
              </tr>

              <tr>
                  <th>Sub Total</th>
                  <td> <?php echo $data['total']; ?> </td>
              </tr>

              <tr>
                  <th>Bayar</th>
                  <td><?php echo $data['bayar']; ?> </td>
              </tr>

              <tr>
                  <th>Kembali</th>
                  <td> <?php echo $data['kembali']; ?> </td>
              </tr>
            
            </table>
          </div>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- this row will not appear when printing -->
      <div class="row no-print">
        <div class="col-xs-12">
          <a href="coba.php" target="_blank" class="btn btn-default"><i class="fa fa-print"></i> Print</a>
          <button type="button" class="btn btn-success pull-right"><i class="fa fa-credit-card"></i> Submit Payment
          </button>
          <button type="button" class="btn btn-primary pull-right" style="margin-right: 5px;">
            <i class="fa fa-download"></i> Generate PDF
          </button>
        </div>
      </div>
    </section>

    <script type="text/javascript">
    
    function hitung(){

        var total_bayar = document.getElementById('total_bayar').value;

        var diskon = document.getElementById('diskon').value;

        var diskon_pot = parseInt(total_bayar) * parseInt(diskon) / parseInt(100);

        if (!isNaN(diskon_pot)) {

            var potongan = document.getElementById('potongan').value = diskon_pot;
        }

        var sub_total = parseInt(total_bayar) - parseInt(potongan);

        if (!isNaN(sub_total)) {

            var s_total = document.getElementById('s_total').value = sub_total;
        }

        var bayar = document.getElementById('bayar').value;

        var bayar_b = parseInt(bayar) - parseInt(s_total);

        if (!isNaN(bayar_b)) {

            document.getElementById('kembali').value = bayar_b;
        }
    }

</script>