<?php 

	error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
	
	$koneksi = new mysqli("localhost", "root", "", "dbpos");

	$kasir = $_GET['kasir'];

	$kode_pj = $_GET['kode_pjl'];

	$id_user = $_GET['user'];


 ?>

 <style>
 	
 		@media print {
 			input.noPrint{
 				display: none;
 			}
 		}

 </style>

 <h4>Struk Belanja</h4>
 <hr>

 <table>
 	<?php 
 	$sql = $koneksi->query("select * from tb_user where id_user='$user'");
    
    $data = $sql->fetch_assoc();

 	 ?>
 	<tr>
 		<td><?php echo $data['nama_toko']; ?></td>
 	</tr>



 </table>

 <table>
 	
 	<?php 

 		$sql = $koneksi->query("select * from tb_transaksi where id_user='$id_user' and kode_transaksi='$kode_pj'");

 		$tampil = $sql->fetch_assoc();

 	?>

 	<tr>
 		<td>Kode Transaksi &nbsp&nbsp</td>
 		<td>: &nbsp&nbsp <?php echo $tampil['kode_transaksi']; ?></td>
 	</tr>

 	<tr>
 		<td>Tanggal Transaksi &nbsp&nbsp</td>
 		<td>: &nbsp&nbsp <?php echo $tampil['tgl_transaksi']; ?></td>
 	</tr>

 	<tr>
 		<td>Penjual &nbsp&nbsp</td>
 		<td>: &nbsp&nbsp <?php echo $kasir; ?></td>
 	</tr>
 </table>
 <hr>



<table>
	<?php 

	$sql2 = $koneksi->query("select * from tb_transaksi, tb_transaksi_detail, tb_barang 
								where tb_transaksi.kode_transaksi=tb_transaksi_detail.kode_transaksi
								and tb_transaksi.kode_barcode=tb_barang.kode_barcode 
								and tb_barang.id_user=tb_transaksi.id_user
								and tb_transaksi.kode_transaksi='$kode_pj'");

	

	while ($tampil2 = $sql2->fetch_assoc()) {
		
	


 ?>
 	<tr>
 		
 		
 		<td><?php echo $tampil2['nama_barang']; ?></td>
 		<td><?php echo number_format($tampil2['harga_jual']).',-'.'&nbsp'.'&nbsp'.'X'.'&nbsp'.'&nbsp'.$tampil2['jumlah'].'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp' ?></td>
 		<td><?php echo number_format($tampil2['total']).',-'; ?></td>
 	</tr>

 	<?php 


 			$diskon 		= $tampil2['diskon'];
 			$potongan 		= $tampil2['potongan'];
 			$bayar 			= $tampil2['bayar'];
 			$kembali 		= $tampil2['kembali'];
 			$total_b 		= $tampil2['total_b'];
 			$total_bayar 	= $total_bayar + $tampil2['total'];
 		}

 	 ?>


 	 <tr>
 	 	
 	 	<td><hr></td>

 	 </tr>
 	<tr>
 		<th colspan="2">Total</th>
 		<td>: <?php echo $total_bayar; ?></td>
 	</tr>

 	<tr>
 		<th colspan="2">Diskon</th>
 		<td>: <?php echo $diskon; ?></td>
 	</tr>

 	<tr>
 		<th colspan="2">Potongan Diskon</th>
 		<td>: <?php echo $potongan; ?></td>
 	</tr>

 	<tr>
 		<th colspan="2">Sub Total</th>
 		<td>: <?php echo $total_b; ?></td>
 	</tr>

 	<tr>
 		<th colspan="2">Bayar</th>
 		<td>: <?php echo $bayar; ?></td>
 	</tr>

 	<tr>
 		<th colspan="2">Kembali</th>
 		<td>: <?php echo $kembali; ?></td>
 	</tr>



</table>
	<tr>
 	 	
 	 	<td><hr></td>

 	</tr>

<table>
	<tr>
 		<th colspan="2">UMKMPOS</th>
 		<td>&nbsp&nbsp&nbsp&nbspTerima Kasih Sudah Berbelanja di Toko Kami</td>
 	</tr>

</table>

<br>

<input type="button" value="Cetak" class="noPrint" onclick="window.print()">


