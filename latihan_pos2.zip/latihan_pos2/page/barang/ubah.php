<script>
function sum() {

    var harga_beli = document.getElementById('harga_beli').value;
    var harga_jual = document.getElementById('harga_jual').value;
    var result =parseInt(harga_jual) - parseInt(harga_beli);
    if (!isNaN(result)) {
        document.getElementById('profit').value = result;
    }

}
</script>

<?php 

    $id_user = $_GET['id'];

    $sql2 = $koneksi->query("select tb_user.id_user, tb_user.nama, tb_barang.id from tb_user, tb_barang where tb_user.id_user=tb_barang.id");
    $sql = $koneksi->query("select * from tb_barang where id ='$id_user'");
    $tampil = $sql->fetch_assoc();

    $satuan = $tampil['satuan'];


 ?>

<div class="row">
    <div class="col-md-12">
     <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">Edit Barang</h3>
            </div>

                <div class="body">
                <form method="POST" enctype="multipart/form-data">


                <div class="box-body">

                     <label for="">Id User</label>
                    <div class="form-group">
                       <input type="text" name="id_user" value="<?php echo $tampil['id_user']; ?>" class="form-control" readonly="" />
                    </div>

                <label for="">Kode Barcode</label>
                    <div class="form-group">
                       <input type="text" name="kode_barcode" value="<?php echo $tampil['kode_barcode']; ?>" class="form-control" />
                    </div>
                

                    <label for="">Nama Barang</label>
                  
                      <div class="form-group">
                        <input type="text" name="nama_barang" value="<?php echo $tampil['nama_barang']; ?>" class="form-control" />
                      </div>
                

                    <label for="">Satuan</label>
                      
                      <div class="form-group">
                        <select name="satuan"class="form-control show-tick">
                            <option value="Pack"<?php if ($satuan=='Pack'){ echo "selected"; } ?>>Pack</option>
                            <option value="Lusin"<?php if ($satuan=='Lusin'){ echo "selected"; } ?>>Lusin</option>
                            <option value="PCS"<?php if ($satuan=='PCS'){ echo "selected"; } ?>>PCS</option>
                        </select>
                      </div>
                 

                    <label for="">Stok</label>
                      <div class="form-group">
                        <input type="number" name="stok" value="<?php echo $tampil['stok']; ?>" class="form-control" />
                      </div>
                

                    <label for="">Harga Beli</label>
                      <div class="form-group">
                        <input type="number" name="harga_beli" id="harga_beli" onkeyup="sum()" value="<?php echo $tampil['harga_beli']; ?>" class="form-control" />
                      </div>
               

                    <label for="">Harga Jual</label>
                      <div class="form-group">
                        <input type="number" name="harga_jual" id="harga_jual" onkeyup="sum()" value="<?php echo $tampil['harga_jual']; ?>" class="form-control" />
                      </div>


                    <label for="">Profit</label>
                      <div class="form-group">
                        <input type="number" name="profit" value="<?php echo $tampil['profit']; ?>" id="profit" readonly="" style="background-color: #e7e3e9;" value="0" class="form-control" />
                      </div>

                    <label for="">Gambar</label>
                  
                      <div class="form-group">
                        <img src="dist/img/<?php echo $tampil['foto']; ?>" width="100" height="100" alt="">
                      </div>

                    <label for="">Ganti Gambar</label>
                  
                      <div class="form-group">
                        <input type="file" name="foto" class="form-control" />
                      </div>
               

                    <input type="submit" name="simpan" value="Simpan" class="btn btn-primary">

                </div>
            </form>
        </div>
    </div>



    <?php 

        if (isset($_POST['simpan'])) {
            
            
            $kode_barcode = $_POST['kode_barcode'];
            $nama_barang = $_POST['nama_barang'];
            $satuan = $_POST['satuan'];
            $stok = $_POST['stok'];
            $harga_beli = $_POST['harga_beli'];
            $harga_jual = $_POST['harga_jual'];
            $profit = $_POST['profit'];

            $foto = $_FILES['foto']['name'];
            $lokasi = $_FILES['foto']['tmp_name'];

            if (!empty($lokasi)) {

            $upload = move_uploaded_file($lokasi,"dist/img/".$foto);


            $sql2 = $koneksi->query("update tb_barang set kode_barcode='$kode_barcode', nama_barang='$nama_barang', satuan='$satuan', harga_beli='$harga_beli', stok='$stok', harga_jual='$harga_jual', profit='$profit', foto='$foto' where id='$id_user'");

            if ($sql2) {
                ?> 

                    <script type="text/javascript">
                        alert("Data Berhasil Diubah");
                        window.location.href="?page=barang";
                    </script>

                <?php  
              }
            }else{
              $sql2 = $koneksi->query("update tb_barang set kode_barcode='$kode_barcode', nama_barang='$nama_barang', satuan='$satuan', harga_beli='$harga_beli', stok='$stok', harga_jual='$harga_jual', profit='$profit' where id='$id_user'");

              if ($sql2) {
                ?> 

                    <script type="text/javascript">
                        alert("Data Berhasil Disimpan");
                        window.location.href="?page=barang";
                    </script>

                <?php 
                } 
            }
        }

     ?>