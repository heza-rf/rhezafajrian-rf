<section class="content-header">
<div class="box">
  
  <div class="box-header">
        <h3 class="box-title">Data Produk</h3>
  </div>

<div class="box-body table-responsive no-padding">

  <div class="col-md-12">
    <br>
    <table id="example1" class="table table-bordered table-striped">
      <thead>
      <tr>
        <th>No</th>
        <th>Kode Barcode</th>
        <th>Nama Barang</th>
        <th>Satuan</th>
        <th>Stok</th>
        <th>Harga Beli</th>
        <th>Harga Jual</th>
        <th>Profit</th>
        <th>Gambar</th>

        <th>Aksi</th>
      </tr>
      </thead>

    <tbody>
      <?php 

        $no = 1;

        $sql = $koneksi->query("select * from tb_barang where id_user='$user'");

        while ($data = $data = $sql->fetch_assoc()){

        ?>
    <tr>
      <td><?php echo $no++; ?></td>
     
      <td><?php echo $data['kode_barcode']; ?></td>
      <td><?php echo $data['nama_barang']; ?></td>
      <td><?php echo $data['satuan']; ?></td>
      <td><?php echo $data['stok']; ?></td>
      <td><?php echo number_format($data['harga_beli']) ?></td>
      <td><?php echo number_format($data['harga_jual']) ?></td>
      <td><?php echo number_format($data['profit']) ?></td>
      <td><img src="dist/img/<?php echo $data['foto']; ?>" width="50" height="50"> </td>

      

      <td><a href="?page=barang&aksi=ubah&id=<?php echo $data['id'] ?>" title="Edit" class="btn btn-success glyphicon glyphicon-edit" ></a>
          <a onclick="return confirm('Apakah Anda Akan Menghapus Data Barang Ini ?')" href="?page=barang&aksi=hapus&id=<?php echo $data['kode_barcode'] ?>" title="Hapus" class="btn btn-danger glyphicon glyphicon-trash" ></a></td>
    </tr>
    <?php } ?>
  </tbody>
  </table>
  <a href="?page=barang&aksi=tambah" class="btn btn-primary" >Tambah</a>
  <br><br>
</div>
</div>
</div>
</section>


